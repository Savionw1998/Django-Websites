from django.urls import path
from . import views

urlpatterns = [
    path('', views.Home),
    path('photography', views.Photography),
    path('videography', views.Videography),
    path('gallery', views.Gallery),
    path('contact', views.Contact),
    path('message', views.CreateMessage),
]