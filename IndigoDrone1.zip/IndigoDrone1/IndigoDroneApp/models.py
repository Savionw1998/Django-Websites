from django.db import models

import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class MessageManager(models.Manager):
    def message_validator(self, postData):
        errors = {}
        if len(postData["name"]) < 2:
            errors["name"] = "Name should be at least 2 characters"
        if not EMAIL_REGEX.match(postData['email']):
            errors["email"] = "Email not valid"
        if len(postData["message"]) < 2:
            errors["message"] = "Message should be at least 2 characters"
        return errors

class Message(models.Model):
    name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    message = models.CharField(max_length=255)
    objects = MessageManager()

