from django.apps import AppConfig


class IndigodroneappConfig(AppConfig):
    name = 'IndigoDroneApp'
