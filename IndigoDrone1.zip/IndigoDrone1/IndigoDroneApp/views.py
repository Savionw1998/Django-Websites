from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Message

def Home(request):
    return render(request, 'home.html')
def Photography(request):
    return render(request, 'photography.html')
def Videography(request):
    return render(request, 'videography.html')
def Gallery(request):
    return render(request, 'gallery.html')
def Contact(request):
    return render(request, 'contact.html')
def CreateMessage(request):
    if request.method == "POST":
        errors = Message.objects.message_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect('/contact')
        else:
            new_message = Message.objects.create(
                name = request.POST['name'],
                email = request.POST['email'],
                message = request.POST['message'],
            )
            return redirect('/')
