from django.apps import AppConfig


class AffiliateappConfig(AppConfig):
    name = 'affiliateapp'
