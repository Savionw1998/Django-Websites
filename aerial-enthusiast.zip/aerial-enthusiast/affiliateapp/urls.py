from django.urls import path
from . import views

urlpatterns = [
    path('', views.Home),
    path('gear', views.Gear),
    path('about', views.About),
    path('contact', views.Contact),
    path('message', views.CreateMessage),
]