from django.apps import AppConfig


class ProjectTwoAppConfig(AppConfig):
    name = 'project_two_app'
